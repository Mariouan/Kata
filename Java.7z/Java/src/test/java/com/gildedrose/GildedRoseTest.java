package com.gildedrose;

import static org.junit.Assert.*;

import org.junit.Test;

public class GildedRoseTest {
	
	
	@Test
    public void qualityDegradesSellByDateNotPassedTest() { 

        Item[] items = new Item[] {
                new Item("+5 Dexterity Vest", 20, 20), 
                new Item("Elixir of the Mongoose", 20, 20),                
                new Item("Conjured Mana Cake", 20, 20) 
                };

        GildedRose app = new GildedRose(items);
        app.updateQuality();
        
        assertEquals(19, app.items[0].quality);
        assertEquals(19, app.items[1].quality);
        assertEquals(18, app.items[2].quality);
        
	}
		
	@Test
    public void qualityDegradesSellByDatePassedTest() { 

        Item[] items = new Item[] {
                new Item("+5 Dexterity Vest", -1, 20), 
                new Item("Elixir of the Mongoose", -1, 20),                 
                new Item("Conjured Mana Cake", -1, 20) 
                };

        GildedRose app = new GildedRose(items);
        app.updateQuality();
        
        assertEquals(18, app.items[0].quality);
        assertEquals(18, app.items[1].quality);
        assertEquals(16, app.items[2].quality); 
        
	} 

	
	@Test
    public void itemQualityNeverNegativeValueTest() { 

        Item[] items = new Item[] {
                new Item("+5 Dexterity Vest", -1, 0), 
                new Item("Elixir of the Mongoose", -1, 0),                 
                new Item("Conjured Mana Cake", -1, 0) 
                };

        GildedRose app = new GildedRose(items);
        app.updateQuality();
        
        assertEquals(0, app.items[0].quality);
        assertEquals(0, app.items[1].quality);
        assertEquals(0, app.items[2].quality); 
        
	} 


	
	@Test
    public void itemQualityNeverExceeds50Test() { 

        Item[] items = new Item[] {
                new Item("Aged Brie", 10, 50), 
                new Item("Backstage passes to a TAFKAL80ETC concert", 3, 50)
                };

        GildedRose app = new GildedRose(items);
        app.updateQuality();
        
        assertEquals(50, app.items[0].quality);
        assertEquals(50, app.items[1].quality); 
        
	}
	
	@Test
    public void ageBrieQualityIncreaseTest() { 

        Item[] items = new Item[] { new Item("Aged Brie", 20, 20) }; 

        GildedRose app = new GildedRose(items);
        app.updateQuality();        
        assertEquals(21, app.items[0].quality); 
        
	}
	
	@Test
    public void BackstageQualityIncreaseTest() { 

        Item[] items = new Item[] { new Item("Backstage passes to a TAFKAL80ETC concert", 20, 20) }; 

        GildedRose app = new GildedRose(items);
        app.updateQuality();        
        assertEquals(21, app.items[0].quality); 
        
	}
	
	@Test
    public void BackstageQualityIncreaseBy2Test() { 

        Item[] items = new Item[] { new Item("Backstage passes to a TAFKAL80ETC concert", 9, 20) }; 

        GildedRose app = new GildedRose(items);
        app.updateQuality();        
        assertEquals(22, app.items[0].quality); 
        
	}
	
	@Test
    public void BackstageQualityIncreaseBy3Test() { 

        Item[] items = new Item[] { new Item("Backstage passes to a TAFKAL80ETC concert", 4, 20) }; 

        GildedRose app = new GildedRose(items);
        app.updateQuality();        
        assertEquals(23, app.items[0].quality); 
        
	}
	
	@Test
    public void sulfurasQualityNotAlteredSellByDatePassedTest() { 

        Item[] items = new Item[] { new Item("Sulfuras, Hand of Ragnaros", 20, 80) }; 

        GildedRose app = new GildedRose(items);
        app.updateQuality();        
        assertEquals(80, app.items[0].quality); 
        
	}
	
	@Test
    public void sulfurasQualityNotAlteredSellByDateNotPassedTest() { 

        Item[] items = new Item[] { new Item("Sulfuras, Hand of Ragnaros", 20, 80) }; 

        GildedRose app = new GildedRose(items);
        app.updateQuality();        
        assertEquals(80, app.items[0].quality); 
        
	}
	

    @Test
    public void ConjuredQualityDegradesSellByDateNotPassedTest() {
        Item[] items = new Item[] { new Item("Conjured Mana Cake", 3, 20) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertEquals("Conjured Mana Cake", app.items[0].name);
        assertEquals(18, app.items[0].quality);
    }

    @Test
    public void ConjuredQualityDegradesSellByDatePassedTest() {
        Item[] items = new Item[] { new Item("Conjured Mana Cake", -1, 20) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertEquals("Conjured Mana Cake", app.items[0].name);
        assertEquals(16, app.items[0].quality);
    }
 

}
